// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"P\u00e4ise kontroller",signin:"Logi sisse",signout:"Logi v\u00e4lja",about:"Info",signInTo:"Logi sisse",cantSignOutTip:"See funktsioon pole eelvaatere\u017eiimis rakendatav.",more:"rohkem",_localized:{}}});