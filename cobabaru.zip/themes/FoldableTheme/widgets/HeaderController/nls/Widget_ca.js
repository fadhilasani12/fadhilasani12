// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/nls/strings":{_widgetLabel:"Controlador de cap\u00e7alera",signin:"Inicia la sessi\u00f3",signout:"Tanca la sessi\u00f3",about:"Quant a",signInTo:"Inicia la sessi\u00f3 al",cantSignOutTip:"Aquesta funci\u00f3 no est\u00e0 disponible en el mode de visualitzaci\u00f3 pr\u00e8via.",more:"m\u00e9s",_localized:{}}});