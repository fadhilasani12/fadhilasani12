// All material copyright ESRI, All Rights Reserved, unless otherwise specified.
// See http://js.arcgis.com/3.15/esri/copyright.txt and http://www.arcgis.com/apps/webappbuilder/copyright.txt for details.
//>>built
define({"themes/FoldableTheme/widgets/HeaderController/setting/nls/strings":{group:"N\u00e9v",openAll:"\u00d6sszes megnyit\u00e1sa egy panelen",dropDown:"Megjelen\u00edt\u00e9s leny\u00edl\u00f3 men\u00fcsorban",noGroup:"Nincs be\u00e1ll\u00edtva widgetcsoport.",groupSetLabel:"Widgetcsoportok tulajdons\u00e1gainak be\u00e1ll\u00edt\u00e1sa",_localized:{}}});